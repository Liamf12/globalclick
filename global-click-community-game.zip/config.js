// Paste your Supabase project values here.
// In Supabase: Project Settings -> API.
// These are safe to expose in browser code when Row Level Security is configured correctly.
window.SUPABASE_URL = "PASTE_SUPABASE_URL_HERE";
window.SUPABASE_ANON_KEY = "PASTE_SUPABASE_ANON_KEY_HERE";