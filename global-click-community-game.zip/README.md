# GLOBAL CLICK — Multiplayer Community Clicker

## 1. Create the database
Create a free Supabase project.

Open **SQL Editor**, paste `supabase.sql`, and run it.

Then in Supabase Dashboard -> Database -> Replication/Realtime, enable Realtime for `public.game_state`.

## 2. Add your project keys
Open `config.js` and replace:
- PASTE_SUPABASE_URL_HERE
- PASTE_SUPABASE_ANON_KEY_HERE

Find these under Supabase Project Settings -> API.

## 3. Run the website
Upload the folder to any static host (GitHub Pages, Netlify, Vercel, Cloudflare Pages, etc.).

Do NOT put a service-role key in `config.js`. Only use the public anon/publishable key.

## How the multiplayer system works
Every click calls a PostgreSQL RPC (`perform_click`) that atomically adds the click power to the shared global counter. Supabase Realtime broadcasts changes to connected browsers, so everybody sees the shared counter change.

The player's own spendable clicks and upgrade levels are stored separately. Upgrade purchases are also performed server-side with an atomic RPC.

## Difficulty
Upgrade prices use:
base cost × 1.18^level

The multipliers become extremely expensive at high levels, intentionally making late-game progress slow and community-driven.

## Files
- index.html — game interface
- style.css — design
- app.js — gameplay/client
- config.js — Supabase connection
- supabase.sql — database + secure RPC functions
